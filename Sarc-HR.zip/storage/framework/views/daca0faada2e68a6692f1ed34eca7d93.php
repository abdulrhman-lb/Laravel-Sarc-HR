<footer class="bg-danger text-lg-start">
    <!-- Grid container -->
    
    <!-- Grid container -->
  
    <!-- Copyright -->
    <div class="text-center p-3 " style="background-color: rgba(209, 231, 211, 1); ">
      © 2023 Copyright:
      <a class="text-dark" href="https://mdbootstrap.com/">SARC</a>
    </div>
    <!-- Copyright -->
  </footer><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/layouts/footer.blade.php ENDPATH**/ ?>