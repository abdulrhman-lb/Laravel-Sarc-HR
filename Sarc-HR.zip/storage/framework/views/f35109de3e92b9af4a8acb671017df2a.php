

<?php $__env->startSection('content'); ?>
<div class="container">
    <h5 class="d-flex fw-bold justify-content-center pb-3">إضافة دورة تدريبية جديدة</h5>
    <form action="/mytraining" method="get">
        <div class="row row-cols-lg-1 g-3 align-items-center mb-3">
            <div class="col-12">
                <label class="m-2">اختر الدورة...</label>
                <select class="form-select <?php $__errorArgs = ['pr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tr" name="tr" >
                <option>-</option>
                <?php $__currentLoopData = $lists['trainings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($training -> id); ?>" <?php echo e($lists['training'] == $training -> id  ? 'selected' : ''); ?>><?php echo e($training -> training . ' - ' . $training -> training_en); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['pr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="hidden" name="pr" value="<?php echo e($lists['profile']); ?>">
            </div>
            <div class="col-12">
                <button type="submit" class="block">عرض الدورات المتاحة</button>
            </div>
        </div>
    </form>
        <table class="table table-bordered mt-3">
            <tr>
                <th class="centered-content" colspan="8">الدورات التدريبيبة المتاحة</th>
            </tr>
            <tr>   
                <th class="centered-content">مكان التدريب</th>
                <th class="centered-content">تاريخ بدء التدريب</th>
                <th class="centered-content">تاريخ نهاية التدريب</th>
                <th class="centered-content">عدد أيام التدريب</th>
                <th class="centered-content">المدربين</th>
                <th class="centered-content"></button></a></th>
            </tr>
            <?php $__currentLoopData = $lists['training_courses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <td class="centered-content"><?php echo e($training_course -> training_place); ?></td>
                    <td class="centered-content"><?php echo e($training_course -> training_date_start); ?></td>
                    <td class="centered-content"><?php echo e($training_course -> training_date_end); ?></td>
                    <td class="centered-content"><?php echo e($training_course -> training_days_number); ?></td>
                    <td class="centered-content">
                    <table class="table table-bordered">
                        <?php $__currentLoopData = $training_course -> training_trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                          <tr>
                            <td>
                              <?php echo e($trainer -> trainer -> trainer); ?> 
                              <br>
                              <?php echo e($trainer -> trainer -> trainer_en); ?> 
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                    </td>
                    <td class="centered-content">
                      <form action="/mytraining" method="POST">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="tr" value="<?php echo e($training_course -> id); ?>">
                          <input type="hidden" name="pr" value="<?php echo e($lists['profile']); ?>">
   
                          <button type="submit" class="btn btn-success my-1" onclick ="return confirm('هل تريد بالتأكيد إضافة هذه الدورة إلى الدورات المتبعة ؟')"><i class="fa fa-add"></i></button>  
                      </form>  
                  </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/profile/addtraining.blade.php ENDPATH**/ ?>