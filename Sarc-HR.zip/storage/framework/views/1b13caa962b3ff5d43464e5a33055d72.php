<?php $__env->startSection('content'); ?>
<div class="container containerlist">
    
    <h4 class="d-flex fw-bold justify-content-center py-3">لا يمكن استعادة كلمة المرور حالياً . الرجاء الاتصال بمسؤول النظام</h4>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>