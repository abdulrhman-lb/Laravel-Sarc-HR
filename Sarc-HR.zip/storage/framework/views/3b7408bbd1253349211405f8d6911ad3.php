

<?php $__env->startSection('content'); ?>

<div class="container">
    <h4 class="d-flex fw-bold justify-content-center pb-3">قائمة الموظفين</h4>
</div>
<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
<?php
    $image = '';
    if (($profile -> image) == '' ) {
        $image = 'non_m.png';
    } else {
        $image = 'profiles/' . $profile -> image; 
    }
?>      
<div class="container containerlist">
    <img src="/images/<?php echo e($image); ?>" alt="Avatar" style="width:90px">
    <div>
        <span class="fw-bold"><?php echo e($profile -> first_name . ' ' . $profile -> father_name . ' ' . $profile -> last_name); ?></span>
        <?php if($profile -> jop_title_id == 1): ?>
            <div class="badge bg-info text-dark"><?php echo e($profile-> jop_title -> jop_title); ?></div>
        <?php else: ?>
            <div class="badge bg-warning text-dark"><?php echo e($profile-> jop_title -> jop_title); ?></div>
        <?php endif; ?> 
        <div class="badge bg-success">فعال</div>
        
    </div>
    <div class="pe-2">
        <?php echo e($profile-> department->department . ' - ' . $profile->department->department_en . ' - ' . $profile->department->department_short); ?>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/profile/profilelist.blade.php ENDPATH**/ ?>