

<?php $__env->startSection('content'); ?>
<div class="container">
    <h5 class="d-flex fw-bold justify-content-center pb-3">إضافة متدرب جديد للدورة</h5>
    <form action="<?php echo e(action('TrainingTraineeController@store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="formGroupExampleInput2" class="form-label">اختر اسم المتدرب</label>
            <input type="hidden" name="training_course_id" value="<?php echo e($lists['id']); ?>">
            <select class="form-select <?php $__errorArgs = ['trainee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="trainee_id" name="trainee_id">
                <?php $__currentLoopData = $lists['trainees']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($trainee -> id); ?> <?php echo e($trainee -> id == old('trainee') ? 'selected' : ''); ?>"><?php echo e($trainee -> first_name . ' ' . $trainee -> father_name . ' ' . $trainee -> last_name . ' - ' . $trainee -> full_name_en); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['trainee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-floating">
            <button type="submit" class="block">حفظ</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/trainee/create.blade.php ENDPATH**/ ?>