<footer class="bg-danger text-lg-start">
    <!-- Grid container -->
    {{-- <div class="container p-4 mx-auto">
      <!--Grid row-->
      <div class="row">
        <!--Grid column-->
        <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
          <h5 class="text-light">Pages</h5>
            <!--Grid column-->
            <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                <ul class="list-unstyled mb-0">
                <li>
                    <a href="#!" class="link-light">Home</a>
                </li>
                <li>
                    <a href="#!" class="link-light">Blog</a>
                </li>
                <li>
                    <a href="#!" class="link-light">Login</a>
                </li>
                <li>
                    <a href="#!" class="link-light">Register</a>
                </li>
                </ul>
            </div>
            <!--Grid column-->
        </div>
        <!--Grid column-->
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div> --}}
    <!-- Grid container -->
  
    <!-- Copyright -->
    <div class="text-center p-3 " style="background-color: rgba(209, 231, 211, 1); ">
      © 2023 Copyright:
      <a class="text-dark" href="https://mdbootstrap.com/">SARC</a>
    </div>
    <!-- Copyright -->
  </footer>