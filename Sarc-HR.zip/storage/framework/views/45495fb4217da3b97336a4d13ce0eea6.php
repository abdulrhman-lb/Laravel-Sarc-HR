

<?php $__env->startSection('content'); ?>
<div class="container">
    <h5 class="d-flex fw-bold justify-content-center pb-3">الفرق والأقسام في الهلال الأحمر العربي السوري</h5>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
          <div class="card h-100 border-primary">
            <div class="card-header text-bg-light"><?php echo e($department -> department); ?></div>
            <div class="card-body">
              <h5 class="card-title"><?php echo e($department -> department_en); ?></h5>
              <p class="card-text">منسق الفريق : <?php echo e($department -> coordinator_name); ?></p>
            </div>
            <a href="/teams/<?php echo e($department -> id); ?>" class="btn btn-primary">عرض المزيد ...</a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/department/index.blade.php ENDPATH**/ ?>