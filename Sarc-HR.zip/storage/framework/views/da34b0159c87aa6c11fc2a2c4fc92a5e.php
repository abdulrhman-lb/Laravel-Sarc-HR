

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3">جدول الدورات التدريبية</h5>
        <div>
            <button type="button" class="fw-bold collapsible"> تصفية حسب...  </button>
            <div class="content ">    
                <form action="/training" method="get" class="containerlist">
    
                    <div class="row row-cols-lg-5 g-5 align-items-center mb-3 ">
    
                        <div class="col-12">
                            <label class="m-1">اسم الدورة</label>
                            <select class="form-select" id="training_id" name="tn" >
                                <option value="" selected>-</option>
                                <?php $__currentLoopData = $lists['training']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($training -> id); ?>" <?php echo e($lists['training_selected'] == $training -> id  ? 'selected' : ''); ?>><?php echo e($training -> training  . ' - ' . $training -> training_en); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
    
                        <div class="col-12">
                            <label class="m-1"> مكان التدريب </label>
                            <input type="text" class="form-control " id="training_place" name="tp" value="<?php echo e($lists['training_place_selected']); ?>">
                        </div>
                        <div class="col-12">
                            <label class="m-2">التاريخ من</label>
                            <input type="text" class="form-control  <?php $__errorArgs = ['td1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="training_date_start1" name="td1" value="<?php echo e($lists['training_date_start1_selected']); ?>">
                            <?php $__errorArgs = ['td1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
 
                        <div class="col-12">
                            <label class="m-2">التاريخ إلى</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['td2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="training_date_start2" name="td2" value="<?php echo e($lists['training_date_start2_selected']); ?>">
                            <?php $__errorArgs = ['td2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
    
                        <div class="col-12 ">
                            <label class="m-2">فرز حسب</label>
                            <select class="form-select" id="sort" name="sort" >
                                <option value="" selected>-</option>
                                <option value="training_id" <?php echo e($lists['sort_selected'] == 'training_id'  ? 'selected' : ''); ?>>اسم الدورة</option>
                                <option value="training_place" <?php echo e($lists['sort_selected'] == 'training_place'  ? 'selected' : ''); ?>>مكان التدريب</option>
                                <option value="training_date_start" <?php echo e($lists['sort_selected'] == 'training_date_start'  ? 'selected' : ''); ?>>تاريخ بداية الدورة</option>
                                <option value="training_days_number" <?php echo e($lists['sort_selected'] == 'training_days_number'  ? 'selected' : ''); ?>>عدد أيام التدريب</option>
                            </select>
                        
                            <label class="m-2">نوع الفرز</label>
                            <select class="form-select" id="order" name="order" >
                                <option value="asc" <?php echo e($lists['order_selected'] == 'asc'  ? 'selected' : ''); ?>>تصاعدي</option>
                                <option value="desc" <?php echo e($lists['order_selected'] == 'desc'  ? 'selected' : ''); ?>>تنازلي</option>
                            </select>
                        </div>
                        <br>
                    </div>
    
                    <div class="row row-cols-lg-2 g-2 align-items-center mb-3" style="width: 100%; float: inline-start; justify-self: center;">
                        
                        <div class="col-12">
                            <button type="submit" class="block">تطبيق عوامل التصفية والفرز</button>
                        </div>
    
                        <div class="col-12">
                            <a href="/training?tn=&tp=&td=&sort=&order=asc"><button type="button" class="block">تصفير عوامل التصفية والفرز</button></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <table class="table table-bordered mt-3">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">اسم الدورة</th>
                <th class="centered-content">مكان التدريب</th>
                <th class="centered-content">تاريخ التدريب</th>
                <th class="centered-content" colspan="3"><a href="/training/create"><button type="button" class="btn btn-success my-1">إضافة دورة جديدة</button></a></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $lists['trainings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content"><?php echo e($training -> training  . ' - '. $training -> training_en); ?></td>
                    <td class="centered-content"><?php echo e($training -> training_place); ?></td>
                    <td class="centered-content"><?php echo e($training -> training_date_start); ?></td>
                    <td class="centered-content">
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/training/<?php echo e($training -> id); ?>"><button type="button"  title="عرض تفاصيل الدورة" class="btn btn-primary my-1 "><i class="fa fa-eye"></i></button></a>
                            <a href="/training/<?php echo e($training -> id); ?>/edit"><button type="button"  title="تعديل بيانات الدورة" class="btn btn-success my-1"><i class="fa fa-edit"></i></button></a>
                            <button type="submit" class="btn btn-danger my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الدورة التدريبية ؟')"><i class="fa fa-trash"></i></button>  
                            <span class="m-2">|</span>
                            <a href="trainee/<?php echo e($training -> id); ?>"><button type="button" title="المتدربين" class="btn btn-info my-1 notification"><i class="fas fa-book-reader"></i><span class="badge"><?php echo e($training -> trainee_count); ?></span></button></a>
                            <a href="trainer/<?php echo e($training -> id); ?>"><button type="button" title="المدربين" class="btn btn-warning my-1 notification"><i class="fas fa-chalkboard-teacher"></i><span class="badge"><?php echo e($training -> trainers_count); ?></span></button></a>
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/training/index.blade.php ENDPATH**/ ?>