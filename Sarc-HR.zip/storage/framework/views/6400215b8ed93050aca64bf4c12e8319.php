

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="d-flex fw-bold justify-content-center pb-3">تعديل بيانات المستخدم</h4>
    <h4 class="d-flex fw-bold justify-content-center pb-3"><?php echo e($users -> username); ?></h4>
    <form action="/conf/update/<?php echo e($users -> id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="formGroupExampleInput2" class="form-label">صلاحيات المستخدم</label>
            <select class="form-select" id="role" name="role">
                <option value="0" <?php echo e($users -> role == '0'  ? 'selected' : ''); ?>>مستخدم عادي</option>
                <option value="1" <?php echo e($users -> role == '1'  ? 'selected' : ''); ?>>مستخدم مدير</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="formGroupExampleInput2" class="form-label">حالة المستخدم</label>
            <select class="form-select" id="active" name="active">
                <option value="0" <?php echo e($users -> active == '0'  ? 'selected' : ''); ?>>غير فعال</option>
                <option value="1" <?php echo e($users -> active == '1'  ? 'selected' : ''); ?>>فعال</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label"> إعادة تعيين كلمة المرور</label>
            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-floating">
            <button type="submit" class="block">حفظ التعديلات</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/auth/edit.blade.php ENDPATH**/ ?>