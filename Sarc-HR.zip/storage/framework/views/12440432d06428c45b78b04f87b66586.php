

<?php $__env->startSection('content'); ?>
<div class="container">
  
  <table class="table table-bordered">  
    <tr>
      <th class="centered-content" colspan="7">استعراض بيانات المدرب المحدد</th>
    </tr> 
    <tr>
      <th class="centered-content">اسم المدرب</th>
      <th class="centered-content">اسم المدرب باللغة الانكليزية</th>
    </tr>
    <tr class="pt-3 ">
      <td class="centered-content"><?php echo e($lists['trainer']-> trainer); ?></td>
      <td class="centered-content"><?php echo e($lists['trainer']->trainer_en); ?></td>
    </tr>
  </table>


  <table class="table table-bordered mt-4">
    <tr>
        <th class="centered-content" colspan="7">الدورات التدريبيبة التي شارك بها</th>
    </tr>
    <tr>
        <th class="centered-content">#</th>
        <th class="centered-content">اسم الدورة</th>
        <th class="centered-content">مكان التدريب</th>
        <th class="centered-content">تاريخ بدء التدريب</th>
        <th class="centered-content">تاريخ نهاية التدريب</th>
        <th class="centered-content">عدد أيام التدريب</th>
    </tr>
    <?php
        $count = 0;
    ?>
    <?php $__currentLoopData = $lists['trainers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
        <tr class="pt-3 ">
            <?php
                $count++;
            ?>
            <td class="fw-bold centered-content"><?php echo e($count); ?></td>
            <td class="centered-content"><?php echo e($trainer -> training_course -> training -> training . ' - ' . $trainer -> training_course -> training -> training_en); ?></td>
            <td class="centered-content"><?php echo e($trainer -> training_course -> training_place); ?></td>
            <td class="centered-content"><?php echo e($trainer -> training_course -> training_date_start); ?></td>
            <td class="centered-content"><?php echo e($trainer -> training_course -> training_date_end); ?></td>
            <td class="centered-content"><?php echo e($trainer -> training_course -> training_days_number); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <div class="form-floating">
    <a href="/const/trainer"><button type="button" class="block">عودة لصفحة جدول المدربين</button></a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/const/trainer/show.blade.php ENDPATH**/ ?>