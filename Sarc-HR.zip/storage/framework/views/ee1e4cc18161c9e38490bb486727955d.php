

<?php $__env->startSection('content'); ?>
<div class="container">
  <h4 class="d-flex fw-bold justify-content-center pb-3">استعراض بيانات الحالة الاجتماعية المحددة</h4>
    <table class="table table-bordered">   
      <tr class="pt-3 ">
        <td class="fw-bold centered-content">الحالة الاجتماعية</td>
        <td class="centered-content"><?php echo e($marital_statuses-> marital_status); ?></td>
      </tr>
      <tr class="pt-3 ">
        <td class="fw-bold centered-content">الحالة الاجتماعية باللغة الانكليزية</td>
        <td class="centered-content"><?php echo e($marital_statuses->marital_status_en); ?></td>
      </tr>
    </table>
    <div class="form-floating">
      <a href="/const/maritalstatus"><button type="button" class="block">عودة لصفحة جدول الحالات الاجتماعية</button></a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/const/maritalstatus/show.blade.php ENDPATH**/ ?>