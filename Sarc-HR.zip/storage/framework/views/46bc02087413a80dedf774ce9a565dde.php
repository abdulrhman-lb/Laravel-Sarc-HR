

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3"> العقوبات</h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">الاسم الثلاثي</th>
                <th class="centered-content">العقوبة</th>
                <th class="centered-content">تاريخ العقوبة</th>
                <th class="centered-content">مصدر العقوبة</th>
                <th class="centered-content">سبب العقوبة</th>
                <th class="centered-content" colspan="3"><a href="penalty/create"><button type="button" class="btn btn-success my-1">إضافة عقوبة لموظف</button></a></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $penalties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penalty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content"><?php echo e($penalty -> profile -> first_name . ' ' . $penalty -> profile -> father_name . ' ' . $penalty -> profile -> last_name); ?></td>
                    <td class="centered-content"><?php echo e($penalty -> penalty_name -> penalty_name); ?></td>
                    <td class="centered-content"><?php echo e($penalty -> penalty_date); ?></td>
                    <td class="centered-content"><?php echo e($penalty -> penalty_source); ?></td>
                    <td class="centered-content"><?php echo e($penalty -> penalty_reason); ?></td>
                    <td class="centered-content">
                        <form action="<?php echo e(action('PenaltyController@destroy', $penalty -> id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/penalty/<?php echo e($penalty -> id); ?>"><button type="button" class="btn btn-primary my-1"><i class="fa fa-eye"></i></button></a>
                            <a href="/penalty/<?php echo e($penalty -> id); ?>/edit"><button type="button" class="btn btn-success my-1"><i class="fa fa-edit"></i></button></a>
                            <button type="submit" class="btn btn-danger my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا العقوبة ؟')"><i class="fa fa-trash"></i></button>  
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/penalty/index.blade.php ENDPATH**/ ?>