<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\php\xampp\htdocs\Sarc-HR\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>