

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h5 class="d-flex fw-bold justify-content-center pb-3"> السيرة الهلالية للموظفين</h5>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">الاسم الثلاثي</th>
                <th class="centered-content">القسم</th>
                <th class="centered-content">المنصب</th>
                <th class="centered-content">المنصب باللغة الانكليزية</th>
                <th class="centered-content">الصفة الهلالية</th>
                <th class="centered-content">بدء العمل بتاريخ</th>
                <th class="centered-content">أنهى العمل بتاريخ</th>
                <th class="centered-content" colspan="3"><a href="position/create"><button type="button" class="btn btn-success my-1">إضافة تنقل لموظف</button></a></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                        $i = 0;
                        if ($position -> end_date == "1900-01-01") {
                            $end_date='حتى الآن';
                            $i = 1;
                        } else {
                            $end_date=$position -> end_date;}
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($position -> profile -> first_name . ' ' . $position -> profile -> father_name . ' ' . $position -> profile -> last_name); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($position -> department -> department); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($position -> position); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($position -> position_en); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($position -> jop_title -> jop_title); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($position -> start_date); ?></td>
                    <td class="centered-content <?php echo e($i == 1 ? 'fw-bold' : ''); ?>"><?php echo e($end_date); ?></td>
                    <td class="centered-content">
                        
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/position/<?php echo e($position -> id); ?>"><button type="button" class="btn btn-primary my-1"><i class="fa fa-eye"></i></button></a>
                            
                            
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/position/index.blade.php ENDPATH**/ ?>