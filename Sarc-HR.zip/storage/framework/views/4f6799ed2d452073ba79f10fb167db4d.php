
<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-success" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>


<?php if((auth()-> check()) && (auth()->user()-> active == '0')): ?>
    <div class="container containerlist">
        <h5 class="d-flex fw-bold justify-content-center py-3">عذرا هذا المستخدم غير فعال الرجاء مراجعة قسم الموارد البشرية...</h5>
    </div>
<?php endif; ?>
    <div class="hero-bg-image " style="background: url('images/sarc.jpg') no-repeat center center/cover;" >
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/index.blade.php ENDPATH**/ ?>