

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-warning" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>
    <div class="container">
        <h4 class="d-flex fw-bold justify-content-center pb-3">جدول الجنس</h4>
        <table class="table table-bordered">
            <tr>
                <th class="centered-content">#</th>
                <th class="centered-content">الجنس</th>
                <th class="centered-content">الجنس باللغة الانكليزية</th>
                <th class="centered-content" colspan="3"><a href="/const/gener/create"><button type="button" class="btn btn-success my-1">إضافة جنس جديد</button></a></th>
            </tr>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $geners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gener): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <tr class="pt-3 ">
                    <?php
                        $count++;
                    ?>
                    <td class="fw-bold centered-content"><?php echo e($count); ?></td>
                    <td class="centered-content"><?php echo e($gener -> gener); ?></td>
                    <td class="centered-content"><?php echo e($gener -> gener_en); ?></td>
                    <td class="centered-content">
                        <form action="<?php echo e(action('GenerController@destroy', $gener -> id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <a href="/const/gener/<?php echo e($gener -> id); ?>"><button type="button" class="btn btn-primary my-1"><i class="fa fa-eye"></i></button></a>
                            <a href="/const/gener/<?php echo e($gener -> id); ?>/edit"><button type="button" class="btn btn-success my-1"><i class="fa fa-edit"></i></button></a>
                            <button type="submit" class="btn btn-danger my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الجنس ؟')"><i class="fa fa-trash"></i></button>  
                        </form>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/const/gener/index.blade.php ENDPATH**/ ?>