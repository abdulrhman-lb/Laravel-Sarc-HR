

<?php $__env->startSection('content'); ?>
<div class="container">
  <h5 class="d-flex fw-bold justify-content-center pb-3">استعراض بيانات الشعبة المحددة</h5>
  <table class="table table-bordered">   
    <tr class="pt-3 ">
      <td class="fw-bold centered-content">اسم الشعبة</td>
      <td class="centered-content"><?php echo e($sub_branches-> sub_branch); ?></td>
    </tr>
    <tr class="pt-3 ">
      <td class="fw-bold centered-content">اسم الشعبة باللغة الانكليزية</td>
      <td class="centered-content"><?php echo e($sub_branches->sub_branch_en); ?></td>
    </tr>
    <tr class="pt-3 ">
      <td class="fw-bold centered-content">اسم الفرع التابعة له</td>
      <td class="centered-content"><?php echo e($sub_branches -> branch -> branch . ' - ' . $sub_branches -> branch -> branch_en); ?></td>
    </tr>
  </table>
  <div class="form-floating">
    <a href="/const/subbranch"><button type="button" class="block">عودة لصفحة جدول الشعب</button></a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/const/subbranch/show.blade.php ENDPATH**/ ?>