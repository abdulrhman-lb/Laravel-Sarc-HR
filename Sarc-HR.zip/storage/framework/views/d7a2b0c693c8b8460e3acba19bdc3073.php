

<?php $__env->startSection('content'); ?>
<div class="container">
  <h5 class="d-flex fw-bold justify-content-center pb-3">استعراض بيانات القسم المحدد</h5>
    <table class="table table-bordered">   
      <tr class="pt-3 ">
        <td class="fw-bold centered-content">اسم القسم</td>
        <td class="centered-content"><?php echo e($departments-> department); ?></td>
      </tr>
      <tr class="pt-3 ">
        <td class="fw-bold centered-content">اسم القسم باللغة الانكليزية</td>
        <td class="centered-content"><?php echo e($departments->department_en); ?></td>
      </tr>
      <tr class="pt-3 ">
        <td class="fw-bold centered-content">اختصار اسم القسم</td>
        <td class="centered-content"><?php echo e($departments->department_short); ?></td>
      </tr>
    </table>
    <div class="form-floating">
      <a href="/const/department"><button type="button" class="block">عودة لصفحة جدول الأقسام</button></a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/const/department/show.blade.php ENDPATH**/ ?>