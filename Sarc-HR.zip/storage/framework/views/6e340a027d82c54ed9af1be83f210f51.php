<?php echo e($slot); ?>

<?php /**PATH D:\php\xampp\htdocs\Sarc-HR\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>