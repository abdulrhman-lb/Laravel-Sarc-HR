

<?php $__env->startSection('content'); ?>
<style>
  .t-r{
  justify-content: flex-end; 
}
</style>
<div class="container"> 
    <h4 class="d-flex fw-bold justify-content-center pb-3">المعلومات الشخصية</h4>
    
    
    <table class="table table-borderless">   
          <?php
            $image = '';
            if (($profile -> image) == '' ) {
              $image = 'non_m.png';
                if (($profile -> gener) == 'Female-أنثى') {
                  $image = 'non_f.png';
                }
                
            } else {
                $image = 'profiles/' . $profile -> image; 
            }
          ?>
        <tr class="pt-3 ">
            <td class="centered-content" colspan="2"><img src="/images/<?php echo e($image); ?>" class="img-pro" alt="..."></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الفرع</td>
          <td class="centered-content"><?php echo e($profile-> branch->branch . ' - ' . $profile->branch->branch_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الشعبة</td>
          <td class="centered-content"><?php echo e($profile->sub_branch->sub_branch . ' - ' . $profile->sub_branch->sub_branch_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">النقطة</td>
          <td class="centered-content"><?php echo e($profile -> point); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">القسم</td>
          <td class="centered-content"><?php echo e($profile-> department->department); ?> <br> <?php echo e($profile->department->department_en . ' - ' . $profile->department->department_short); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الاسم الكامل</td>
          <td class="centered-content"><?php echo e($profile -> first_name . ' ' . $profile -> last_name); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">اسم الأب</td>
          <td class="centered-content"><?php echo e($profile -> father_name); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">اسم الأم</td>
          <td class="centered-content"><?php echo e($profile -> mother_name); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الرقم الوطني</td>
          <td class="centered-content"><?php echo e($profile -> national_number); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الجنس</td>
          <td class="centered-content"><?php echo e($profile -> gener -> gener . ' - ' . $profile -> gener -> gener_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">مكان الولادة</td>
          <td class="centered-content"><?php echo e($profile -> birth_place); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">تاريخ الولادة</td>
          <td class="centered-content"><?php echo e($profile -> birth_date); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الحالة الاجتماعية</td>
          <td class="centered-content"><?php echo e($profile -> marital_status -> marital_status . ' - ' . $profile -> marital_status -> marital_status_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">رقم الموبايل</td>
          <td class="centered-content"><?php echo e($profile -> mobile_phone); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">رقم الهاتف</td>
          <td class="centered-content"><?php echo e($profile -> phone); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">البريد الالكتروني</td>
          <td class="centered-content"><?php echo e($profile -> email); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الشهادة العلمية</td>
          <td class="centered-content"><?php echo e($profile->certificate->certificate . ' - ' . $profile->certificate->certificate_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">تفاصيل الشهادة العلمية </td>
          <td class="centered-content"><?php echo e($profile -> certificate_details); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الصفة الهلالية</td>
          <td class="centered-content"><?php echo e($profile -> jop_title -> jop_title . ' - ' . $profile -> jop_title -> jop_title_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">المنصب</td>
          <td class="centered-content"><?php echo e($profile -> position); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">تاريخ التطوع</td>
          <td class="centered-content"><?php echo e($profile -> volunteering_date); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">تاريخ التوظيف</td>
          <td class="centered-content"><?php echo e($profile -> hire_date); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">زمرة الدم</td>
          <td class="centered-content"><?php echo e($profile -> blood_group); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">الاسم الكامل باللغة الالنكليزية</td>
          <td class="centered-content"><?php echo e($profile -> full_name_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">المنصف باللغة الانكليزية</td>
          <td class="centered-content"><?php echo e($profile -> position_en); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">مقاس الحذاء</td>
          <td class="centered-content"><?php echo e($profile -> shoes_size); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">مقاس الخصر</td>
          <td class="centered-content"><?php echo e($profile -> waist_size); ?></td>
        </tr>
        <tr class="pt-3 ">
          <td class="fw-bold centered-content">مقاس الكتفين</td>
          <td class="centered-content"><?php echo e($profile -> shoulders_size); ?></td>
        </tr>
    </table>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/profile/myprofile.blade.php ENDPATH**/ ?>