<div class="container">
    <div class="jeg_nav_row">
        <div class="jeg_nav_col jeg_nav_left jeg_nav_grow">
            <div class="item_wrap jeg_nav_alignleft">
                <div class="jeg_main_menu_wrapper">
                    <div class="jeg_nav_item jeg_mainmenu_wrap">
                        <ul class="jeg_menu jeg_main_menu jeg_menu_style_2 sf-js-enabled sf-arrows" data-animation="animate" style="touch-action: pan-y;"><li id="menu-item-174" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-174 bgnav" data-item-row="default"><a title="glyphicon glyphicon-home" href="https://sarc.sy">الرئيسية</a></li>
                            <li id="menu-item-180" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-180 bgnav" data-item-row="default"><a href="#" class="sf-with-ul">من نحن؟</a></li>
                            <li id="menu-item-49243" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-49243 bgnav" data-item-row="default"><a href="#" class="sf-with-ul">الأخبار</a></li>
                            <li id="menu-item-50488" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-50488 bgnav" data-item-row="default"><a href="https://sarc.sy/ar/قصص-المنظمة/">قصص المنظمة</a></li>
                            <li id="menu-item-50527" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-50527 bgnav" data-item-row="default"><a href="https://sarc.sy/الزاوية-الإعلامية/">الزاوية الإعلامية</a></li>
                            <li id="menu-item-181" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-181 bgnav" data-item-row="default"><a href="#" class="sf-with-ul">انضم إلينا</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/layouts/tabs.blade.php ENDPATH**/ ?>