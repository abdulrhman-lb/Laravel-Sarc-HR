

<?php $__env->startSection('content'); ?>
    <div class="container containerlist">
        <h4 class="d-flex fw-bold justify-content-center py-3">هذا المستخدم لا يملك ملف شخصي بعد ...</h4>
        <a href="/profile/create"><button type="submit" class="block my-3">إنشاء ملف شخصي</button></a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/profile/redi.blade.php ENDPATH**/ ?>