

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="container alert alert-success" role="alert">
        <?php echo e(session()->get('message')); ?>

    </div> 
<?php endif; ?>

<div class="container">
    <h5 class="d-flex fw-bold justify-content-center pb-1">قائمة الموظفين</h5>
    <div>
        <button type="button" class="fw-bold collapsible">تصفية حسب...</button>
        <div class="content ">    
            <form action="/profile" method="get" class="containerlist">

                <div class="row row-cols-lg-4 g-4 align-items-center mb-3 " style="width: 75%; float: right;">

                    <div class="col-12">
                        <label class="m-1">الفرع</label>
                        <select class="form-select" id="branch_id" name="br" >
                            <option value="" selected>-</option>
                            <?php $__currentLoopData = $lists['branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch -> id); ?>" <?php echo e($lists['branch_selected'] == $branch -> id  ? 'selected' : ''); ?>><?php echo e($branch -> branch . ' - ' . $branch -> branch_en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="m-1">الشعبة</label>
                        <select class="form-select" id="sub_branch_id" name="sb" >
                        <option value="" selected>-</option>
                        <?php $__currentLoopData = $lists['sub_branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sub_branch -> id); ?>" <?php echo e($lists['sub_branch_selected'] == $sub_branch -> id  ? 'selected' : ''); ?>><?php echo e($sub_branch -> sub_branch . ' - ' . $sub_branch -> sub_branch_en); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="m-1">القسم</label>
                        <select class="form-select " id="department_id" name="dp">
                            <option value="" selected>-</option>
                            <?php $__currentLoopData = $lists['departments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department -> id); ?>" <?php echo e($lists['department_selected'] == $department -> id  ? 'selected' : ''); ?>><?php echo e($department -> department . ' - ' . $department -> department_en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="m-1"> الاسم </label>
                        <input type="text" class="form-control " id="first_name" name="nm" value="<?php echo e($lists['first_name_selected']); ?>">
                    </div>

                    <div class="col-12">
                        <label class="m-1"> الكنية </label>
                        <input type="text" class="form-control " id="last_name" name="ln" value="<?php echo e($lists['last_name_selected']); ?>">
                    </div>    

                    <div class="col-12">
                        <label class="m-1">الجنس</label>
                        <select class="form-select " id="gender_id" name="gn">
                            <option value="" selected>-</option>
                            <?php $__currentLoopData = $lists['genders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gender -> id); ?>" <?php echo e($lists['gender_selected'] == $gender -> id  ? 'selected' : ''); ?>><?php echo e($gender -> gender . ' - ' . $gender -> gender_en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="m-1">الحالة الاجتماعية</label>
                        <select class="form-select" id="marital_status_id" name="ms">
                            <option selected value="">-</option>
                            <?php $__currentLoopData = $lists['marital_statuses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($marital_status -> id); ?>" <?php echo e($gender -> id); ?>" <?php echo e($lists['marital_status_selected'] == $marital_status -> id  ? 'selected' : ''); ?>><?php echo e($marital_status -> marital_status . ' - ' . $marital_status -> marital_status_en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="m-1">الشهادة العلمية</label>
                        <select class="form-select" id="certificate_id" name="cf">
                            <option selected value="">-</option>
                            <?php $__currentLoopData = $lists['certificates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($certificate -> id); ?>" <?php echo e($certificate -> id); ?>" <?php echo e($lists['certificate_selected'] == $certificate -> id  ? 'selected' : ''); ?>><?php echo e($certificate -> certificate . ' - ' . $certificate -> certificate_en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12"> 
                        <label class="m-1">تفاصيل الشهادة العلمية</label>
                        <input type="text" class="form-control" id="certificate_details" name="cd" value="<?php echo e($lists['certificate_details_selected']); ?>">  
                    </div>

                    <div class="col-12">
                        <label class="m-1">حسب الصفة الهلالية</label>
                        <select class="form-select" id="jop_title_id" name="jt">
                            <option selected value="">-</option>
                            <?php $__currentLoopData = $lists['jop_titles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jop_title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jop_title -> id); ?>" <?php echo e($lists['jop_title_selected'] == $jop_title -> id  ? 'selected' : ''); ?>><?php echo e($jop_title -> jop_title . ' - ' . $jop_title -> jop_title_en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="m-1">الحالة</label>
                        <select class="form-select" id="ac" name="ac">    
                            <option value="-" <?php echo e($lists['active_selected'] == '-'  ? 'selected' : ''); ?>>-</option>
                            <option value="0" <?php echo e($lists['active_selected'] == '0'  ? 'selected' : ''); ?>>غير فعال</option>
                            <option value="1" <?php echo e($lists['active_selected'] == '1'  ? 'selected' : ''); ?>>فعال</option>
                        </select>
                    </div>

                </div>

                <div class="align-items-center mb-3 containerlist" style="width: 25%; float: left;">
                    <div class="col-12">
                        <label class="m-2">فرز حسب</label>
                        <select class="form-select" id="sort" name="sort" >
                            <option value="" selected>-</option>
                            <option value="first_name" <?php echo e($lists['sort_selected'] == 'first_name'  ? 'selected' : ''); ?>>الاسم</option>
                            <option value="last_name" <?php echo e($lists['sort_selected'] == 'last_name'  ? 'selected' : ''); ?>>الكنية</option>
                            <option value="branch_id" <?php echo e($lists['sort_selected'] == 'branch_id'  ? 'selected' : ''); ?>>الفرع</option>
                            <option value="sub_branch_id" <?php echo e($lists['sort_selected'] == 'sub_branch_id'  ? 'selected' : ''); ?>>الشعبة</option>
                            <option value="department_id" <?php echo e($lists['sort_selected'] == 'department_id'  ? 'selected' : ''); ?>>القسم</option>
                            <option value="gender_id" <?php echo e($lists['sort_selected'] == 'gender_id'  ? 'selected' : ''); ?>>الجنس</option>
                            <option value="marital_status_id" <?php echo e($lists['sort_selected'] == 'marital_status_id'  ? 'selected' : ''); ?>>الحالة الاجتماعية</option>
                            <option value="certificate_id" <?php echo e($lists['sort_selected'] == 'certificate_id'  ? 'selected' : ''); ?>>الشهادة العلمية</option>
                            <option value="jop_title_id" <?php echo e($lists['sort_selected'] == 'jop_title_id'  ? 'selected' : ''); ?>>الصفة الهلالية</option>
                            <option value="birth_place" <?php echo e($lists['sort_selected'] == 'birth_place'  ? 'selected' : ''); ?>>تاريخ الميلاد</option>
                            <option value="volunteering_date" <?php echo e($lists['sort_selected'] == 'volunteering_date'  ? 'selected' : ''); ?>>تاريخ التطوع</option>
                            <option value="hire_date" <?php echo e($lists['sort_selected'] == 'hire_date'  ? 'selected' : ''); ?>>تاريخ التوظيف</option>
                        </select>
                    </div>
                    <br>
                    <div class="col-12">
                        <label class="m-2">نوع الفرز</label>
                        <select class="form-select" id="order" name="order" >
                            <option value="asc" <?php echo e($lists['order_selected'] == 'asc'  ? 'selected' : ''); ?>>تصاعدي</option>
                            <option value="desc" <?php echo e($lists['order_selected'] == 'desc'  ? 'selected' : ''); ?>>تنازلي</option>
                        </select>
                    </div>
                    <br>
                </div>

                <div class="row row-cols-lg-2 g-2 align-items-center mb-3" style="width: 100%; float: inline-start; justify-self: center;">
                    
                    <div class="col-12">
                        <button type="submit" class="block">تطبيق عوامل التصفية والفرز</button>
                    </div>

                    <div class="col-12">
                        <a href="/profile?br=&sb=&dp=&nm=&ln=&gn=&ms=&cf=&cd=&jt=&ac=-&sort=&order=asc"><button type="button" class="block">تصفير عوامل التصفية والفرز</button></a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php $__currentLoopData = $lists['profiles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <?php
            $image = '';
            if (($profile -> image) == '' ) {
                $image = 'non_m.png';
            } else {
                $image = 'profiles/' . $profile -> image; 
            }
        ?>      
        <div class="container containerlist">
            <img src="/images/<?php echo e($image); ?>" alt="Avatar" class="img-pro-show">
            <div style="display : inline-block;">
                <span class="fw-bold"><?php echo e($profile -> first_name . ' ' . $profile -> father_name . ' ' . $profile -> last_name); ?></span>
                <div class="activ-button">
                    <?php if($profile -> jop_title_id == 1): ?>
                        <a href="/profile?br=&sb=&dp=&nm=&ln=&gn=&ms=&cf=&cd=&jt=1&ac=-&sort=&order=asc"><div class="badge bg-info text-dark"><?php echo e($profile-> jop_title -> jop_title); ?></div></a>
                    <?php else: ?>
                        <a href="/profile?br=&sb=&dp=&nm=&ln=&gn=&ms=&cf=&cd=&jt=2&ac=-&sort=&order=asc"><div class="badge bg-warning text-dark"><?php echo e($profile-> jop_title -> jop_title); ?></div></a>
                    <?php endif; ?> 
                    <?php if($profile->user->active == '1'): ?>
                        <a href="/profile?br=&sb=&dp=&nm=&ln=&gn=&ms=&cf=&cd=&jt=&ac=1&sort=&order=asc"><div class="badge bg-success">فعال</div></a>
                    <?php else: ?>
                        <a href="/profile?br=&sb=&dp=&nm=&ln=&gn=&ms=&cf=&cd=&jt=&ac=0&sort=&order=asc"><div class="badge bg-danger">غير فعال</div></a>
                    <?php endif; ?> 
                    <?php if($profile->user->role == '1'): ?>
                        <i class="fa fa-star checked" aria-hidden="true"></i>
                    <?php endif; ?> 
                </div>
                <br>
                <span class="fs-6 my-5"> فرع:<?php echo e($profile-> branch->branch . ' - الشعبة:' . $profile->sub_branch->sub_branch); ?></span>
                <br>
                <span class="fs-6 my-5"> <?php echo e($profile-> department->department . ' - ' . $profile->department->department_en . ' - ' . $profile->department->department_short); ?></span>
                <br>
                <span class="fs-6"> <?php echo e($profile-> position . ' - ' . $profile->position_en); ?></span>
            </div>
            <div class="containerbutton" style="display : inline-block;">
                <form action="<?php echo e(action('ProfilesController@destroy', $profile -> id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <a href="/profile/<?php echo e($profile -> user_id); ?>"><button type="button" class="btn btn-primary my-1"><i class="fa fa-eye"></i></button></a>
                    <a href="/profile/<?php echo e($profile -> user_id); ?>/edit"><button type="button" class="btn btn-success my-1"><i class="fa fa-edit"></i></button></a>
                    <button type="submit" class="btn btn-danger my-1" onclick ="return confirm('هل تريد بالتأكيد حذف هذا الملف الشخصي ؟')"><i class="fa fa-trash"></i></button>  
                    <a href="conf/<?php echo e($profile -> user_id); ?>"><button type="button" class="btn btn-info my-1"><i class="fa fa-user"></i></button></a>
                </form> 
            </div>
            
            
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-floating">
        <a href="/export-Profile"><button type="button" class="btn btn-success block">تصدير إلى اكسل</button></a>
      </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\xampp\htdocs\Sarc-HR\resources\views/profile/index.blade.php ENDPATH**/ ?>